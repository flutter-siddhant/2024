package com.example.legalease

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
